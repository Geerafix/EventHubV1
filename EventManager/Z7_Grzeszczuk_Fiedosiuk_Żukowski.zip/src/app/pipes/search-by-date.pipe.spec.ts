import { SearchByDatePipe } from './search-by-date.pipe';

describe('SearchByDatePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchByDatePipe();
    expect(pipe).toBeTruthy();
  });
});
