import { ValidDateDirective } from './valid-date.directive';

describe('ValidDateDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidDateDirective();
    expect(directive).toBeTruthy();
  });
});
